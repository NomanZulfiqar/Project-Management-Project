import { useState } from "react";
import NewProject from "./Components/NewProject";
import NoProject from "./Components/NoProjectAvailable";
import SideBar from "./Components/Sidebar";
import Modal from "./Components/Modal";
import SelectedProject from "./Components/SelectedProject";

function App() {
  const [projectState,setProjectState]=useState({
    projectSelectedId:undefined,
    projects:[],
    task:[]
  })

  function handleAddTask(text){
    setProjectState(prevState=>{
      const taskId=Math.random()
      const newTask={
        text:text,
        id:taskId,
        projectid:prevState.projectSelectedId      
      }
      return{
        ...prevState,
        task:[newTask,...prevState.task],
      }
    })
  }

 function handleDeleteTask(id){
  setProjectState(prevState=>{
    return{
      ...prevState,
      task:prevState.task.filter((task)=>task.id!==id),
    }
  })
 }

  function handleSelectedProject(id){
    setProjectState(prevState=>{
      return{
        ...prevState,
        projectSelectedId:id
      }
    })

  }

  function handleProject(){
    setProjectState(prevState=>{
      return{
        ...prevState,
        projectSelectedId:null
      }
    })
  }

  function handleAddProject(projectData){
    setProjectState(prevState=>{
      const newProject={
        ...projectData,
        id:Math.random()
      }
      return{
        ...prevState,
        projectSelectedId:undefined,
        projects:[...prevState.projects,newProject]
      }
    })

  }

 function handleCancel(){
  setProjectState(prevState=>{
    return{
      ...prevState,
      projectSelectedId:undefined
    }
  })
 }

 function handleDeleteProject(){
  setProjectState(prevState=>{
    return{
      // ...prevState,
      projects:prevState.projects.filter((project)=>project.id!==prevState.projectSelectedId),
      projectSelectedId:undefined
    }
  })
 }
   
 const selectedProject=projectState.projects.find(project=>project.id===projectState.projectSelectedId)

  let content =<SelectedProject project={selectedProject}
   onDelete={handleDeleteProject} onDeleteTask={handleDeleteTask} onAddTask={handleAddTask} task={projectState.task}/>
  if(projectState.projectSelectedId===null){
    content=<NewProject onAdd={handleAddProject} onCancel={handleCancel} />
  }
  else if(projectState.projectSelectedId===undefined){
    content=<NoProject onStartProject={handleProject} />;
  }
 
  
  
  return (
    <main className="h-screen my-8 flex gap-8">
    <SideBar onStartProject={handleProject} project={projectState.projects} onSelectedProject={handleSelectedProject} />
    {content}
    </main>
    
  );
}

export default App;
