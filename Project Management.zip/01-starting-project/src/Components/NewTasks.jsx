import { useState } from "react"

export default function NewTasks({onAdd}){
    const [enteredTask,setEnteredTask]=useState('')

    function handleChange(){
        setEnteredTask(event.target.value);
    }

    function handleClick(){
        if(enteredTask.length===0){
            return;
        }
        onAdd(enteredTask);
        setEnteredTask('');
    }

    return(
        <div>
            <input onChange={handleChange} value={enteredTask} 
            className="bg-stone-600 text-stone-100 my-4 mx-4 py-5 px-5" type="text" />
            <button onClick={handleClick}>Add Tasks</button>
        </div>
    )
}