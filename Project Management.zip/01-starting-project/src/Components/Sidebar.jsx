import Buttons from "./Buttons";

export default function SideBar({onStartProject,project,onSelectedProject}){
    return(
        <aside className="w-1/3  px-8 py-16 bg-stone-900 text-stone-50 md:w-72 rounded-r-xl ">
            <h2 className="mb-8 font-bold uppercase md:text-xl">Your Projects </h2>
            <div>
                <Buttons onClick={onStartProject} >+ ADD PROJECTS</Buttons>
            </div>
            <ul className="mt-2">
                {project.map((project)=>
                    <li key={project.id}>  
                        <button onClick={()=>onSelectedProject(project.id)} className=" my-2 font-bold text-stone-1500 uppercase">{project.title}</button>
                    </li>
                )}
            </ul>
        </aside>
    )
}