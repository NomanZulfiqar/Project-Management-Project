import Buttons from "./Buttons"
import Tasks from "./Tasks"

export default function SelectedProject({project,onDelete,onDeleteTask,onAddTask,task}){
    const formattedDate=new Date(project.dueDate).toLocaleDateString('en-US',{
        year:"numeric",
        month:'short',
        day:'numeric'
    }
    ) 
    return(
        <div className="w-[35rem] mt-16">
            <header className="pb-4 mb-4 border-b-2 border-stone-200">
                <div className='flex items-center justify-between'>
                <h1 className="text-5xl font-bold text-stone-500 my-4">{project.title}</h1>
                <Buttons onClick={onDelete}>Delete</Buttons>
                </div>
                <div>
                    <p className="mb-4 text-stone-900">{project.dueDate}</p>
                    <p className="text-stone-900 whitespace-pre-wrap"> {project.description}</p>
                </div>
            </header>
            <Tasks onAdd={onAddTask} onDelete={onDeleteTask} tasks={task} />
        </div>
    )
}