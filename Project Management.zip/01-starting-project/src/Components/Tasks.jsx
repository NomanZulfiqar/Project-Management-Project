import Buttons from "./Buttons";
import NewTasks from "./NewTasks";

export default function Tasks({ tasks, onAdd, onDelete }) {
    return (
        <section>
            <h1 className="text-5xl font-bold text-stone-500 my-4">New Tasks</h1>
            <NewTasks onAdd={onAdd} />
           {tasks.length===0?<p className="text-bold text-rose-600 ">No task yet</p>: <ul>
                {tasks.map((task) => (
                    <li key={task.id}>
                        <span className="mx-4">{task.text}</span>
                        <Buttons onClick={()=>onDelete(task.id)}>Clear</Buttons>
                    </li>
                    
                ))}
            </ul>
}
        </section>
    );
}
